<h1><a href="http://camohub.github.io/jquery-sortable-lists/index.html">jquery-sortable-lists</a></h1>
<h2 style="font-size:17px">Changelog</h2>

<h3>v2.0.0</h3>
<p>Max levels number has been implemented 
and opener background-image has been removed</p>

<h3>v1.4.0</h3>
<p>Support for mobile devices in jquery-sortable-lists-mobile.js</p>

<h3>v1.3.1</h3>
<p>Support for jquery >=1</p>

<h3>v1.3.0</h3>
<p>Added insertZonePlus option. Fixed bug with ol lists.</p>

<h3>v1.2.0</h3>
<p>Added opener.as option to opener. Now is possible to use opener.as html or class option.</p>

<h3>v1.1.1</h3>
<p>Fixed bug on target parameter of isAllowed callback.</p>

<h3>v1.1.0</h3>
<p>Callback onChange has been implemented.</p>

<h3>v1.0.14</h3>
<p>License have been changed to MIT.</p>

<h3>v1.0.13</h3>
<p>Fixed bug with empty ignoreClass value (as default). If condition checked target.hasClass( setting.ignoreClass ) and ignoreClass was "" it returned always true. This blocked startDragg() call.</p>
