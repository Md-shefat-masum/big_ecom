<ul class="metismenu" id="menu">
    <li>
        <div class="side_bar_top">
            <img src="<?php echo e(asset(''.Auth::user()->photo)); ?>" alt="profile pic">
            <h6><?php echo e(Helper::auth_full_name()); ?></h6>
        </div>
    </li>
    <li>
        <a href="/admin">
            <div class="parent-icon"><i class="fa fa-dashboard"></i></div>
            <div class="menu-title">Dashboard</div>
        </a>
    </li>

    <?php if(Auth::user()->role_id == 1): ?>
        <li>
            <a class="has-arrow" href="#">
                <div class="parent-icon"><i class="zmdi zmdi-view-dashboard"></i></div>
                <div class="menu-title">User Management</div>
            </a>
            <ul class="">
                <li>
                    <a href="<?php echo e(route('admin_user_index')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i> index</a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin_delivery_man_index')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i>Delivery Man List</a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin_user_role_index')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i> User Role</a>
                </li>
            </ul>
        </li>
    <?php endif; ?>

    <li>
        <a class="has-arrow" href="#">
            <div class="parent-icon"><i class="zmdi zmdi-view-dashboard"></i></div>
            <div class="menu-title">Product Management</div>
        </a>
        <ul class="">
            <li>
                <a href="<?php echo e(route('admin_product_list')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i> List</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_product_create')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i> Create Product</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_product_search')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i> Search</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_product_categories')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i> Product Categories</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_product_option')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i> Product Options</a>
            </li>
            <li>
                <a href="#"><i class="zmdi zmdi-dot-circle-alt"></i> Product Filtering</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_product_reviews')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i> Product Reviews</a>
            </li>
            <li>
                <a href="#"><i class="zmdi zmdi-dot-circle-alt"></i> Price Lists</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_product_brands')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i> Brands</a>
            </li>
            <li>
                <a href="<?php echo e(route('product_tax_class')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i> Product Tax Class</a>
            </li>
            <li>
                <a href="<?php echo e(route('product_discount_type')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i> Product Discount Type</a>
            </li>
            <li>
                <a href="<?php echo e(route('product_object_type')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i> Product Object Type</a>
            </li>
            <li>
                <a href="<?php echo e(route('product_condition')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i> Product Condition</a>
            </li>
            <li>
                <a href="<?php echo e(route('country_name')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i>Country Name</a>
            </li>
        </ul>
    </li>

    <li>
        <a class="has-arrow" href="#">
            <div class="parent-icon"><i class="zmdi zmdi-view-dashboard"></i></div>
            <div class="menu-title">Offer Management</div>
        </a>
        <ul class="">
            <li>
                <a href="<?php echo e(route('admin_product_create_campain')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i> Create</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_product_list_campeing')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i> All</a>
            </li>
        </ul>
    </li>

    <li>
        <a class="has-arrow" href="#">
            <div class="parent-icon"><i class="zmdi zmdi-view-dashboard"></i></div>
            <div class="menu-title">Customersss</div>
        </a>
        <ul class="">
            <li>
                <a href="<?php echo e(route('admin_customer_index')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i>View</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_customer_create')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i> Add</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_customer_search')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i> Search</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_customer_import')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i> Import</a>
            </li>
        </ul>
    </li>
    <li>
        <a class="has-arrow" href="#">
            <div class="parent-icon"><i class="zmdi zmdi-view-dashboard"></i></div>
            <div class="menu-title">My Profile</div>
        </a>
        <ul class="">
            <?php
                $data=Auth::user()->id;
            ?>
            <li>
                <a href="<?php echo e(route('admin_profile_edit',$data)); ?>"><i class="zmdi zmdi-dot-circle-alt"></i>Edit Profile</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_profile_change_email',$data)); ?>"><i class="zmdi zmdi-dot-circle-alt"></i>Change Email Address</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_profile_change_password',$data)); ?>"><i class="zmdi zmdi-dot-circle-alt"></i>Change Password</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_profile_additional_authentication')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i>Additional Authentication</a>
            </li>

        </ul>
    </li>
    <li>
        <a class="has-arrow" href="#">
            <div class="parent-icon"><i class="zmdi zmdi-view-dashboard"></i></div>
            <div class="menu-title">Store Setup</div>
        </a>
        <ul class="">
            <li>
                <a href="<?php echo e(route('admin_store_setup_profile')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i>Store Profile</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_store_setup_currencies')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i>Currencies</a>
            </li>

            <li>
                <a href="#"><i class="zmdi zmdi-dot-circle-alt"></i>Payments</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_store_setup_settings')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i>Store Settings Website</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_store_setup_settings_display')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i>Store Settings Display</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_store_setup_settings_share')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i>Store Settings Share</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_store_setup_settings_date')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i>Store Settings Date</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_store_setup_settings_url')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i>Store Settings URL Structure</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_store_setup_settings_security')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i>Store Settings Security & Privacy</a>
            </li>
            <li>
                <a href="#"><i class="zmdi zmdi-dot-circle-alt"></i>Shipping</a>
            </li>

            <li>
                <a href="#"><i class="zmdi zmdi-dot-circle-alt"></i>Tax</a>
            </li>
            <li>
                <a href="#"><i class="zmdi zmdi-dot-circle-alt"></i>Accounting</a>
            </li>



        </ul>
    </li>
    
    <li>
        <a class="has-arrow" href="#">
            <div class="parent-icon"><i class="zmdi zmdi-view-dashboard"></i></div>
            <div class="menu-title">Order Information</div>
        </a>
        <ul class="">
            <li>
                <a href="<?php echo e(route('order_list_pending')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i>Pending Order List</a>
            </li>
            <li>
                <a href="<?php echo e(route('order_list_process')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i>Processing Order List</a>
            </li>
            <li>
                <a href="<?php echo e(route('order_list_complete')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i>Delivery Complete List</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_orders')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i>Orders</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_orders_information')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i>Order Information</a>
            </li>
        </ul>
    </li>
    <li>
        <a class="has-arrow" href="#">
            <div class="parent-icon"><i class="zmdi zmdi-view-dashboard"></i></div>
            <div class="menu-title">Account Settings</div>
        </a>
        <ul class="">

            <li>
                <a href="<?php echo e(route('admin_account_settings_invoices')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i>Invoices and Billing</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_account_settings_payment_method')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i>Payment Method</a>
            </li>
        </ul>
    </li>
    <li>
        <a class="has-arrow" href="#">
            <div class="parent-icon"><i class="zmdi zmdi-view-dashboard"></i></div>
            <div class="menu-title">Storefront</div>
        </a>
        <ul class="">
            <li>
                <a href="<?php echo e(route('admin_storefront_logo')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i>Logo</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_storefront_social_media')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i>Social Media Links</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_storefront_web_pages')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i>Web Pages</a>
            </li>

        </ul>
    </li>
    <li>
        <a href="<?php echo e(route('admin_email')); ?>">
            <div class="parent-icon"><i class="zmdi zmdi-view-dashboard"></i></div>
            <div class="menu-title">Email</div>
        </a>
    </li>


    


    <li class="menu-label">Extra</li>
    <li>
        <a href="/" target="_blank">
            <div class="parent-icon"><i class="fa fa-globe"></i></div>
            <div class="menu-title">Website</div>
        </a>
    </li>
    <li>
        <a  href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault(); confirm('sure!!') && document.getElementById('logout-form').submit();">
            <div class="parent-icon"><i class="fa fa-sign-out"></i></div>
            <div class="menu-title">Logout</div>
        </a>
    </li>

    

</ul>
<?php /**PATH D:\xampp\htdocs\big_ecom\resources\views/admin/layouts/includes/sidebar.blade.php ENDPATH**/ ?>