

<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <div class="container-fluid">
            <?php echo $__env->make('admin.layouts.includes.bread_cumb',['title'=>'User Role Management'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between">
                            <h5 class="card-title">All User Roles</h5>
                            
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">Serial</th>
                                            <th scope="col">created at</th>
                                            <th scope="col">Action</th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($key+1); ?></th>
                                                <td><?php echo e($item->name); ?></td>
                                                <td><?php echo e($item->serial); ?></td>
                                                <td><?php echo e($item->created_at->format('d M Y h:i:s a')); ?></td>
                                                <td>
                                                    <div>
                                                        <a type="button"
                                                            data-toggle="modal" data-target="#updateModal"

                                                            data-url="<?php echo e(route('admin_user_role_update')); ?>"
                                                            data-id="<?php echo e($item->id); ?>"
                                                            data-name="<?php echo e($item->name); ?>"
                                                            data-serial="<?php echo e($item->serial); ?>"

                                                            href=""
                                                            class="role_update_btn btn btn-warning waves-effect waves-light m-1">
                                                            <i class="fa fa-pencil"></i> <span>edit</span>
                                                        </a>
                                                        
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!--start overlay-->
            <div class="overlay"></div>
            <!--end overlay-->
        </div>
        <!-- End container-fluid-->
    </div>
    <!--End content-wrapper-->

    <div class="modal fade" id="updateModal" tabindex="-1" role="dialog" aria-labelledby="updateModalTitle" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="updateModalTitle">Update</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form class="update_role_form" name="update_role_form" action="<?php echo e(route('admin_user_role_update')); ?>" method="POST">
                    <div class="modal-body">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="">
                        <div class="form-group">
                            <label for="">Name</label>
                            <input type="text" class="form-control" name="name" value="">
                        </div>
                        <div class="form-group">
                            <label for="">Serial</label>
                            <input type="number" class="form-control" name="serial" value="">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php $__env->startPush('cjs'); ?>
        <script>
            $('.role_update_btn').on('click',function(){
                let url = $(this).data('url');
                let name = $(this).data('name');
                let serial = $(this).data('serial');
                let id = $(this).data('id');

                console.log(url, name, serial , id);

                $('.update_role_form').attr('url',url);
                $('.update_role_form input[name=name]').val(name);
                $('.update_role_form input[name=serial]').val(serial);
                $('.update_role_form input[name=id]').val(id);

                // update_role_form.name.value = name;
                // update_role_form.id.value = id;
                // update_role_form.serial.value = serial;
            })
        </script>
    <?php $__env->stopPush(); ?>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\big_ecom\resources\views/admin/user_role/index.blade.php ENDPATH**/ ?>