<div class="header_bottom header_bottom7">
    <div class="row align-items-center">
        <div class="col-lg-3 col-md-6">
            <div class="categories_menu categories_seven">
                <div class="categories_title">
                    <h2 class="categori_toggle">ALL CATEGORIES</h2>
                </div>
                <div class="categories_menu_toggle" style="display: <?php echo e(request()->is('/') ? 'block' : 'none'); ?>;" >
                    <ul id="nav_menu">
                        <?php
                            function printNestedArray($a,$parent_id) {
                                // dd($a);
                                $a = (object) $a;
                                $id = $a->id;
                                $category_name = $a->name;
                                $has_child = isset($a->child) && is_array($a->child) && count($a->child)>0;
                                $route = route('website_category_products',[strtolower(str_replace(' ','-',$a->name)),$a->id]);

                                $arrow = "";
                                if($has_child){
                                    $arrow = "<i class='fa fa-angle-right'></i>";
                                }
                                echo "
                                    <li class='menu_item_children'>
                                        <a href='{$route}'> {$category_name}
                                            {$arrow}
                                        </a>
                                ";

                                if ( $has_child ) {
                                    echo "<ul>";
                                        // dd($a->child);
                                        foreach ($a->child as $child) {
                                            $child = (object) $child;
                                            $module = $child->name.'_'.$child->id;
                                            printNestedArray($child,$a->id);
                                        }
                                    echo "</ul>";
                                }

                                echo "</li>";
                            }
                            $categories = App\Http\Controllers\Admin\Product\ProductController::static_categories_tree_json();
                            // dd($categories);
                            foreach ($categories as $key => $category) {
                                $category = (object) $category;
                                printNestedArray($category,$category->id);
                            }
                        ?>
                    </ul>
                </div>
            </div>
        </div>
        <div class=" col-lg-6 colm_none">
            <div class="search_container search_seven_c" id="search_product">
                <form action="#">
                    
                    <div class="search_box">
                        <input type="text" v-model="search_key" style="padding-left:10px;"
                            placeholder="Search Products…" />
                        <button type="submit">Search</button>
                    </div>
                </form>
            </div>

        </div>
        <div class=" col-lg-3 col-md-6">
            <div class="header_bigsale">
                <a href="#">BIG SALE BLACK FRIDAY</a>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\big_ecom\resources\views/frontend/include/header-bottom.blade.php ENDPATH**/ ?>