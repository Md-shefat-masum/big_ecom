

<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <div class="container" id="product_brand">
            <?php echo $__env->make('admin.layouts.includes.bread_cumb',['title'=>'Create Product Options'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="card">
                <div class="card-header">
                    <ul class="filter_nav d-flex flex-wrap">
                        <li>
                            <a href="<?php echo e(route('admin_product_brands')); ?>" class="custom_white_btn">
                                <i class="fa fa-angle-left"></i>
                                Back
                            </a>
                        </li>
                        
                    </ul>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin_product_store_brands')); ?>" id="create_option_form" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="card">
                            <div class="card-header">
                                <h4>Add Brand</h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group"
                                            style="display: flex;
                                                flex-direction: column;
                                                justify-content: space-between;
                                                height: 89%;"
                                        >
                                            <label for="">Brand Name</label>
                                            <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control">
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="d-block text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="card-footer">
                            <button class="btn btn-secondary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>


            <!--start overlay-->
            <div class="overlay"></div>
            <!--end overlay-->
        </div>
        <!-- End container-fluid-->
    </div>
    <!--End content-wrapper-->

    <?php $__env->startPush('cjs'); ?>
        <script src="<?php echo e(asset('contents/admin')); ?>/custom_product_vue.js"></script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Hsblco\big_ecom\resources\views/admin/product/brand/create-brands.blade.php ENDPATH**/ ?>