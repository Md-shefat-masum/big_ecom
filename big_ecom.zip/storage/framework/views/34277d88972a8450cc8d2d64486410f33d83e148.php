

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="container-fluid">
        <h1></h1>
        <div class="page-wrapper">
            <div class="page-content">
                <div class="row">
                    <div class="col-xl-11 mx-auto">

                        <h6 class="mb-0 text-uppercase">Edit Profile</h6>
                        <hr />
                        <p>Set up basic information about you</p>
                        <form method="post" action="<?php echo e(route('admin_profile_update')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                            <input type="hidden" name="role_id" value="<?php echo e($data->role_id); ?>">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">First Name</label>
                                            <input type="text" class="form-control" name="first_name"
                                                value="<?php echo e($data->first_name); ?>">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Last Name</label>
                                            <input type="text" class="form-control" name="last_name"
                                                value="<?php echo e($data->last_name); ?>">
                                        </div>

                                        <div class="col-12">
                                            <button type="submit" class="btn btn-light px-5">Edit</button>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </form>


                    </div>
                </div>
            </div>
        </div>
        <!--start overlay-->
        <div class="overlay"></div>
        <!--end overlay-->
    </div>
    <!-- End container-fluid-->
</div>
<!--End content-wrapper-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\big_ecom\resources\views/admin/nipa/profile/edit.blade.php ENDPATH**/ ?>