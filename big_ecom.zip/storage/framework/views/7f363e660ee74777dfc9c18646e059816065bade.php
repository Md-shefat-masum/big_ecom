<div class="header_bottom header_bottom7">
    <div class="row align-items-center">
        <div class="col-lg-3 col-md-6">
            <div class="categories_menu categories_seven">
                <div class="categories_title">
                    <h2 class="categori_toggle">ALL CATEGORIES</h2>
                </div>
                <div class="categories_menu_toggle" style="display: <?php echo e(request()->is('/') ? 'block' : 'none'); ?>;"  id="home-product-category-top">
                    <ul>

                        <li class="menu_item_children" v-for="(category , index) in home_category" :key="category.id"  v-if="category.id <= limit">
                            <a href="#">{{category.name}}
                                <i class="fa fa-angle-right"></i>
                            </a>
                            <ul class="categories_mega_menu">
                                <li class="menu_item_children menu_item_children_design"
                                    v-for="subcategory in home_category" :key="subcategory.id"
                                    v-if="subcategory.id == category.parent_id">
                                    <a href="#">Dresses1
                                        <i class="fa fa-angle-right"></i>
                                    </a>
                                    
                                </li>
                            </ul>

                        </li>

                        <li v-if="limit <= 9"><a href="#" @click.prevent="getCatLimit"><i class="fa fa-plus" aria-hidden="true"></i> More Categories</a></li>
                        <li v-if="limit >= 10"><a href="#" @click.prevent="getCatLimit"><i class="fa fa-plus" aria-hidden="true"></i> Less Categories</a></li>


                    </ul>
                </div>
            </div>
        </div>
        <div class=" col-lg-6 colm_none">
            <div class="search_container search_seven_c" id="search_product">
                <form action="#">
                    
                    <div class="search_box">
                        <input type="text" v-model="search_key" style="padding-left:10px;"
                            placeholder="Search Products…" />
                        <button type="submit">Search</button>
                    </div>
                </form>
            </div>

        </div>
        <div class=" col-lg-3 col-md-6">
            <div class="header_bigsale">
                <a href="#">BIG SALE BLACK FRIDAY</a>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\Hsblco\big_ecom\resources\views/frontend/include/header-bottom.blade.php ENDPATH**/ ?>