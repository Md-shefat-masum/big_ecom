    <!--banner area start-->
    <div class="banner_area banner_style2 mb-60">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3">
                    <figure class="single_banner">
                        <div class="banner_thumb">
                            <a href="shop.html"><img src="<?php echo e(asset('contents/frontend')); ?>/assets/img/bg/banner6.jpg" alt=""></a>
                        </div>
                    </figure>
                </div>
                <div class="col-lg-6 col-md-6">
                    <figure class="single_banner">
                        <div class="banner_thumb">
                            <a href="shop.html"><img src="<?php echo e(asset('contents/frontend')); ?>/assets/img/bg/banner7.jpg" alt=""></a>
                        </div>
                    </figure>
                </div>
                <div class="col-lg-3 col-md-3">
                    <figure class="single_banner">
                        <div class="banner_thumb">
                            <a href="shop.html"><img src="<?php echo e(asset('contents/frontend')); ?>/assets/img/bg/banner8.jpg" alt=""></a>
                        </div>
                    </figure>
                </div>
            </div>
        </div>
    </div>
    <!--banner area end-->
<?php /**PATH D:\xampp\htdocs\Hsblco\big_ecom\resources\views/frontend/include/add-banner.blade.php ENDPATH**/ ?>