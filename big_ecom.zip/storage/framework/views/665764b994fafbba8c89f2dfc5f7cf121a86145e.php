<div class="header_top">
    <div class="row align-items-center">
        <div class="col-lg-4 col-md-5">
            <div class="antomi_message">
                <p>Get free shipping – Free 30 day money back guarantee</p>
            </div>
        </div>
        <div class="col-lg-8 col-md-7">
            <div class="header_top_settings text-right">
                <ul>
                    
                    <li><a href="#">Track Your Order</a></li>
                    <li>Hotline: <a href="tel:+880 1760686162">+880 1760686162 </a></li>
                    <li style="text-transform: inherit !important;">Email: info@brandszone.com.bd</li>
                </ul>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\xampp\htdocs\big_ecom\resources\views/frontend/include/header-top.blade.php ENDPATH**/ ?>