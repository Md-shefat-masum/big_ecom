<!-- Breadcrumb-->
<div class="row pt-2 pb-2">
    <div class="col-sm-9">
        <h4 class="page-title"><?php echo e($title); ?></h4>
        
    </div>
</div>
<!-- End Breadcrumb-->
<?php /**PATH D:\xampp\htdocs\Hsblco\big_ecom\resources\views/admin/layouts/includes/bread_cumb.blade.php ENDPATH**/ ?>