

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="container-fluid">

        <div class="page-wrapper">
            <div class="page-content">

                <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                    <div class="breadcrumb-title pe-3">Orders</div>


                </div>
                <div class="breadcrumb-subtitle">
                    
                </div>
                <div class="row">
                    <div class="col-xl-9 mx-auto">
                        <h6 class="mb-0 text-uppercase">Archived Invoices</h6>
                        <hr>
                        <div class="card border-top border-0 border-4 border-white">
                            <div class="card-body">
                                <div class="table-responsive" style="padding-bottom: 212px;">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th scope="col">Order Id</th>
                                                <th scope="col">Invoice Id</th>
                                                <th scope="col">View Invoice</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php

                                            $inv=DB::table('order_addresses')->where('invoice_id',$item->invoice_id)->first();
                                            ?>
                                            <tr>
                                                <td><?php echo e($item->id); ?></td>
                                                <td><?php echo e($item->invoice_id); ?></td>
                                                <td>
                                                    <div>
                                                        
                                                        
                                                            <?php if($item->order_status == "process"): ?>
                                                            <a href="<?php echo e(route('delivery_man_assign',$item->id)); ?>"
                                                                class="btn btn-info waves-effect waves-light m-1"><span>Assign Order</span>
                                                            </a>
                                                            <?php endif; ?>
                                                        
                                                        <form action="<?php echo e(route('order_status_update')); ?>" method="post"
                                                            enctype="multipart/form-data">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                                                            <?php if($item->order_status == "accept"): ?>
                                                            <input type="hidden" name="order_status" value="accept">
                                                            <button type="submit"
                                                                class="btn btn-success waves-effect waves-light m-1"><span>Accept</span>
                                                            </button>
                                                            <?php endif; ?>
                                                        </form>

                                                        


                                                        <a type="button" href="<?php echo e(route('invoice_view',$item->id)); ?>"
                                                            class="btn btn-warning waves-effect waves-light m-1"><span>View</span>
                                                        </a>
                                                        

                                                    </div>

                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--start overlay-->
        <div class="overlay"></div>
        <!--end overlay-->
    </div>
    <!-- End container-fluid-->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\big_ecom\resources\views/admin/nipa/account-settings/order-list-process.blade.php ENDPATH**/ ?>