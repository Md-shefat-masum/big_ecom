

<?php $__env->startSection('content'); ?>
<?php

$order_ad=DB::table('order_addresses')->where('invoice_id',$data->invoice_id)->first();
$user=DB::table('users')->where('id',$data->user_id)->first();
$order_info=DB::table('order_information')->where('invoice_id',$data->invoice_id)->get();
?>
<div class="content-wrapper">
    <div class="container-fluid">

        <div class="page-wrapper">
            <div class="page-content">

                <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                    <div class="breadcrumb-title pe-3">Orders</div>


                </div>
                <div class="breadcrumb-subtitle">
                    
                </div>
                <div class="row">
                    <div class="col-xl-9 mx-auto">
                        <h6 class="mb-0 text-uppercase">Archived Invoices</h6>
                        <hr>
                        <div class="card">
                            <div class="card-body">
                                <div class="text-right mb-3">
                                    <a class="btn btn-outline-danger btn-sm mr-5" type="button"
                                        href="javascript:generatePDF()" data-title="PDF">
                                        <i class="mr-1 fa fa-file-pdf-o text-danger-m1 text-120 w-2"></i>
                                        Export
                                    </a>
                                </div>

                                <div id="pdf">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <h1 class="text-uppercase text-info">INVOICE </h1>
                                            <h3 class="text-danger mb-0"><span
                                                    class="font-weight-bold text-uppercase">ID:</span><span
                                                    class="ml-1">
                                                    #<?php echo e($data->invoice_id); ?></span></h3>
                                            <div class="billed"><span
                                                    class="font-weight-bold text-uppercase">TO:</span><span
                                                    class="ml-1"> <?php echo e($order_ad->first_name ?? NUll); ?>

                                                    <?php echo e($order_ad->last_name ?? NUll); ?></span></div>
                                            <div class="billed"><span
                                                    class="font-weight-bold text-uppercase">PHONE:</span><span
                                                    class="ml-1"> <?php echo e($order_ad->phone); ?></span></div>
                                            <div class="billed"><span
                                                    class="font-weight-bold text-uppercase">EMAIL:</span><span
                                                    class="ml-1"> <?php echo e($order_ad->email); ?></span></div>
                                            <div class="billed"><span class="font-weight-bold text-uppercase">ISSUE
                                                    DATE::</span><span class="ml-1"> <?php echo e($data->invoice_date); ?></span></div>


                                        </div>
                                    </div>
                                    <div class="mt-3">

                                        <div class="table-responsive" style="padding-bottom: 212px;">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Product</th>
                                                        <th>Unit</th>
                                                        <th>Price</th>
                                                        <th>Total</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $index=1;
                                                    ?>
                                                    <?php $__currentLoopData = $order_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($index); ?></td>
                                                        <td><?php echo e($item->product_name); ?></td>
                                                        <td><?php echo e($item->qty); ?></td>
                                                        <td><?php echo e($item->price); ?></td>
                                                        <td><?php echo e($item->qty * $item->price); ?></td>
                                                    </tr>
                                                    <?php
                                                    $index++;
                                                    ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    <tr>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                        <td>Total</td>
                                                        <td><?php echo e($data->sub_total); ?></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--start overlay-->
        <div class="overlay"></div>
        <!--end overlay-->
    </div>
    <!-- End container-fluid-->
</div>

<?php $__env->startPush('cjs'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.4/jspdf.debug.js"></script>
<script>
    function generatePDF() {
    var doc = new jsPDF({
        "unit": "px",
        "format": "a4"
    }); //create jsPDF object
    doc.fromHTML(
        document.getElementById("pdf"), // page element which you want to print as PDF
        40,
        0,
        {
            "width": 500,
        },
        function (a) {
            doc.save("invoice.pdf"); // save file name as HTML2PDF.pdf
        }
    );
}


</script>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\big_ecom\resources\views/admin/nipa/account-settings/invoice-view.blade.php ENDPATH**/ ?>