<div class="header_bottom header_bottom7">
    <div class="row align-items-center">
        <div class="col-lg-3 col-md-6">
            <div class="categories_menu categories_seven">
                <div class="categories_title">
                    <h2 class="categori_toggle">ALL CATEGORIES</h2>
                </div>
                <div class="categories_menu_toggle" style="display: {{ request()->is('/') ? 'block' : 'none' }};">
                    <ul>
                        <li class="menu_item_children">
                            <a href="#">Brake Parts
                                <i class="fa fa-angle-right"></i>
                            </a>
                            <ul class="categories_mega_menu">
                                <li class="menu_item_children">
                                    <a href="#">Dresses</a>
                                    <ul class="categorie_sub_menu">
                                        <li><a href="#">Sweater</a></li>
                                        <li><a href="#">Evening</a></li>
                                        <li><a href="#">Day</a></li>
                                        <li><a href="#">Sports</a>
                                            <ul class="categorie_sub_menu_two">
                                                <li><a href="#">Dining room</a></li>
                                                <li><a href="#">bedroom</a></li>
                                                <li><a href="#"> Home & Office</a></li>
                                                <li><a href="#">living room</a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                {{-- <li class="menu_item_children"><a href="#">Handbags</a>
                                                    <ul class="categorie_sub_menu">
                                                        <li><a href="#">Shoulder</a></li>
                                                        <li><a href="#">Satchels</a></li>
                                                        <li><a href="#">kids</a></li>
                                                        <li><a href="#">coats</a></li>
                                                    </ul>
                                                </li>
                                                <li class="menu_item_children"><a href="#">shoes</a>
                                                    <ul class="categorie_sub_menu">
                                                        <li><a href="#">Ankle Boots</a></li>
                                                        <li><a href="#">Clog sandals </a></li>
                                                        <li><a href="#">run</a></li>
                                                        <li><a href="#">Books</a></li>
                                                    </ul>
                                                </li>
                                                <li class="menu_item_children"><a href="#">Clothing</a>
                                                    <ul class="categorie_sub_menu">
                                                        <li><a href="#">Coats Jackets </a></li>
                                                        <li><a href="#">Raincoats</a></li>
                                                        <li><a href="#">Jackets</a></li>
                                                        <li><a href="#">T-shirts</a></li>
                                                    </ul>
                                                </li> --}}
                            </ul>
                        </li>
                        <li class="menu_item_children"><a href="#"> Wheels & Tires <i class="fa fa-angle-right"></i></a>
                            <ul class="categories_mega_menu column_3">
                                <li class="menu_item_children"><a href="#">Chair</a>
                                    <ul class="categorie_sub_menu">
                                        <li><a href="#">Dining room</a></li>
                                        <li><a href="#">bedroom</a></li>
                                        <li><a href="#"> Home & Office</a></li>
                                        <li><a href="#">living room</a></li>
                                    </ul>
                                </li>
                                <li class="menu_item_children"><a href="#">Lighting</a>
                                    <ul class="categorie_sub_menu">
                                        <li><a href="#">Ceiling Lighting</a></li>
                                        <li><a href="#">Wall Lighting</a></li>
                                        <li><a href="#">Outdoor Lighting</a></li>
                                        <li><a href="#">Smart Lighting</a></li>
                                    </ul>
                                </li>
                                <li class="menu_item_children"><a href="#">Sofa</a>
                                    <ul class="categorie_sub_menu">
                                        <li><a href="#">Fabric Sofas</a></li>
                                        <li><a href="#">Leather Sofas</a></li>
                                        <li><a href="#">Corner Sofas</a></li>
                                        <li><a href="#">Sofa Beds</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li class="menu_item_children"><a href="#"> Furnitured & Decor <i
                                    class="fa fa-angle-right"></i></a>
                            <ul class="categories_mega_menu column_2">
                                <li class="menu_item_children"><a href="#">Brake Tools</a>
                                    <ul class="categorie_sub_menu">
                                        <li><a href="#">Driveshafts</a></li>
                                        <li><a href="#">Spools</a></li>
                                        <li><a href="#">Diesel </a></li>
                                        <li><a href="#">Gasoline</a></li>
                                    </ul>
                                </li>
                                <li class="menu_item_children"><a href="#">Emergency Brake</a>
                                    <ul class="categorie_sub_menu">
                                        <li><a href="#">Dolls for Girls</a></li>
                                        <li><a href="#">Girls' Learning Toys</a></li>
                                        <li><a href="#">Arts and Crafts for Girls</a></li>
                                        <li><a href="#">Video Games for Girls</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li class="menu_item_children"><a href="#"> Turbo System <i class="fa fa-angle-right"></i></a>
                            <ul class="categories_mega_menu column_2">
                                <li class="menu_item_children"><a href="#">Check Trousers</a>
                                    <ul class="categorie_sub_menu">
                                        <li><a href="#">Building</a></li>
                                        <li><a href="#">Electronics</a></li>
                                        <li><a href="#">action figures </a></li>
                                        <li><a href="#">specialty & boutique toy</a></li>
                                    </ul>
                                </li>
                                <li class="menu_item_children"><a href="#">Calculators</a>
                                    <ul class="categorie_sub_menu">
                                        <li><a href="#">Dolls for Girls</a></li>
                                        <li><a href="#">Girls' Learning Toys</a></li>
                                        <li><a href="#">Arts and Crafts for Girls</a></li>
                                        <li><a href="#">Video Games for Girls</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li><a href="#"> Lighting</a></li>
                        <li><a href="#"> Accessories</a></li>
                        <li><a href="#">Body Parts</a></li>
                        <li><a href="#">Networking</a></li>
                        <li><a href="#">Perfomance Filters</a></li>
                        <li><a href="#"> Engine Parts</a></li>
                        <li class="hidden"><a href="#">New Sofas</a></li>
                        <li class="hidden"><a href="#">Sleight Sofas</a></li>
                        <li><a href="#" id="more-btn"><i class="fa fa-plus" aria-hidden="true"></i> More
                                Categories</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class=" col-lg-6 colm_none">
            <div class="search_container search_seven_c" id="search_product">
                <form action="#">
                    {{-- <div class="hover_category">
                                        <select class="select_option" name="select" id="categori2">
                                            <option selected value="1">All Categories</option>
                                            <option value="2">Accessories</option>
                                            <option value="3">Accessories & More</option>
                                            <option value="4">Butters & Eggs</option>
                                            <option value="5">Camera & Video </option>
                                            <option value="6">Mornitors</option>
                                            <option value="7">Tablets</option>
                                            <option value="8">Laptops</option>
                                            <option value="9">Handbags</option>
                                            <option value="10">Headphone & Speaker</option>
                                            <option value="11">Herbs & botanicals</option>
                                            <option value="12">Vegetables</option>
                                            <option value="13">Shop</option>
                                            <option value="14">Laptops & Desktops</option>
                                            <option value="15">Watchs</option>
                                            <option value="16">Electronic</option>
                                        </select>
                                    </div> --}}
                    <div class="search_box">
                        <input type="text" v-model="search_key" style="padding-left:10px;"
                            placeholder="Search Products…" />
                        <button type="submit">Search</button>
                    </div>
                </form>
            </div>

        </div>
        <div class=" col-lg-3 col-md-6">
            <div class="header_bigsale">
                <a href="#">BIG SALE BLACK FRIDAY</a>
            </div>
        </div>
    </div>
</div>