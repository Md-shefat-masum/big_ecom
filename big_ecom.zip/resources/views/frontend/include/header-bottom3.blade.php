<div class="header_bottom header_bottom7">
    <div class="row align-items-center">
        <div class="col-lg-3 col-md-6">
            <div class="categories_menu categories_seven">
                <div class="categories_title">
                    <h2 class="categori_toggle">ALL CATEGORIES</h2>
                </div>
                <div class="categories_menu_toggle" style="display: {{ request()->is('/') ? 'block' : 'none' }};">
                    <ul>
                        <li class="menu_item_children">
                            <a href="#">Brake Parts
                                <i class="fa fa-angle-right"></i>
                            </a>
                            <ul class="categories_mega_menu">
                                <li class="menu_item_children">
                                    <a href="#">Dresses
                                        <i class="fa fa-angle-right"></i>
                                    </a>
                                    <ul class="categories_mega_menu_two">
                                        <li class="menu_item_children"><a href="#">Sweater</a></li>
                                        {{-- <li><a href="#">Evening</a></li>
                                        <li><a href="#">Day</a></li> --}}
                                        {{-- <li><a href="#">Sports</a>
                                            <ul class="categorie_sub_menu_two">
                                                <li><a href="#">Dining room</a></li>
                                                <li><a href="#">bedroom</a></li>
                                                <li><a href="#"> Home & Office</a></li>
                                                <li><a href="#">living room</a></li>
                                            </ul>
                                        </li> --}}
                                    </ul>
                                </li>
                              
                            </ul>
                        </li>
           
                    </ul>
                    <ul class="main-category d-lg-block d-md-block d-none">
                        <!--<li>
<a target='_blank' href='https://ajkerdeal.com/category/Eid-Collection'>ঈদ পসরা <i class="fa fa-angle-right" aria-hidden="true"></i></a>
<ul class="sub-category"-->
                        <!--style="height:790px;-->
                        <!--background:#fff;">
<li>
<a target='_blank' href='https://ajkerdeal.com/category/Eid-Collection-Exclusive-design'>এক্সক্লুসিভ ডিজাইন <i class="fa fa-angle-right" aria-hidden="true"></i></a>
<ul class="sub-sub-category">
<li>    <a target='_blank' href='https://ajkerdeal.com/category/Eid-Collection-Exclusive-design-Panjabi'>পাঞ্জাবী  </a></li>
<li>    <a target='_blank' href='https://ajkerdeal.com/category/Eid-Collection-Exclusive-design-Pant'>প্যান্ট  </a></li>
<li>    <a target='_blank' href='https://ajkerdeal.com/category/Eid-Collection-Exclusive-design-Salwar-Kamiz'>থ্রি-পিস  </a></li>
<li>    <a target='_blank' href='https://ajkerdeal.com/category/Eid-Collection-Exclusive-design-Saree'>শাড়ি   </a></li>
<li>    <a target='_blank' href='https://ajkerdeal.com/category/Eid-Collection-Exclusive-design-Shirt'>শার্ট   </a></li>

</ul>

</li>
<li>
<a target='_blank' href='https://ajkerdeal.com/category/Eid-Collection-Family-Eid-Fashion'>ফ্যামিলি ঈদ ফ্যাশন <i class="fa fa-angle-right" aria-hidden="true"></i></a>
<ul class="sub-sub-category">
<li>    <a target='_blank' href='https://ajkerdeal.com/category/Eid-Collection-Family-Eid-Fashion-Couple-Saree-Panjabi'>কাপল অফার </a></li>
<li>    <a target='_blank' href='https://ajkerdeal.com/category/Eid-Collection-Family-Eid-Fashion-Father-Son-Eid-Panjabi'>বাবা-ছেলে </a></li>

</ul>

</li>
<li>
<a target='_blank' href='https://ajkerdeal.com/category/Mens-Shopping-Punjabi'>পাঞ্জাবী</a>

</li>
<li>
<a target='_blank' href='https://ajkerdeal.com/category/Womens-Fashion-Salwar-Kameez'>সালোয়ার-কামিজ </a>
</li>
<li>
<a target='_blank' href='https://ajkerdeal.com/category/Womens-Fashion-Sharee'>শাড়ি</a>
</li>
<li>
<a target='_blank' href='https://ajkerdeal.com/category/Mens-Shopping-T-Shirts'>টি-শার্ট </a>
</li>
<li>
<a target='_blank' href='https://ajkerdeal.com/category/Mens-Shopping-Pants'>
জিন্স ও গ্যাবার্ডিন
</a>

</li>
<li>
<a target='_blank' href='https://ajkerdeal.com/category/Mens-Shopping-Shirts'>
শার্ট

</a>

</li>
<li>
<a target='_blank' href='https://ajkerdeal.com/category/Eid-Collection-Kids-Collection'>
কিডস কালেকশন

</a>

</li>
<li>
<a target='_blank' href='https://ajkerdeal.com/category/Womens-Fashion-Jewellery'>গহনা</a>
</li>-->
                        <!--<li>
<a target='_blank' href='https://ajkerdeal.com/category/Shoes-Sandals'>জুতা ও স্যান্ডেল</a>

</li>
<li>
<a target='_blank' href='https://ajkerdeal.com/category/Womens-Fashion-Bags'>লেডিজ ব্যাগ</a>

</li>
<li>
<a target='_blank' href='https://ajkerdeal.com/category/Belt-Wallet'>বেল্ট ও ওয়ালেট </a>

</li>
<li>
<a target='_blank' href='https://ajkerdeal.com/category/Womens-Fashion-Cosmetics'>কসমেটিক্স</a>
</li>
<li>
<a target='_blank' href='https://ajkerdeal.com/category/Watches-Clock'>ঘড়ি</a>
</li>
<li>
<a target='_blank' href='https://ajkerdeal.com/category/Mens-Shopping-Toiletries-Shaver-Trimmer'>শেভার ও ট্রিমার</a>
</li>
<li>
<a target='_blank' href='https://ajkerdeal.com/category/Bag-Purse-Travel-Bag'>ট্র্যাভেল ব্যাগ</a>
</li>
<li>
<a target='_blank' href='https://ajkerdeal.com/category/Home-Decor'>হোম ডেকোর</a>
</li>
<li>
<a target='_blank' href='https://ajkerdeal.com/category/EMI-Offer'>ইলেকট্রনিক্স ও ফার্নিচার</a>
</li>
<li>
<a target='_blank' href='https://ajkerdeal.com/category/Eid-Poshra-Combo-Offer'>কম্বো অফার</a>
</li>
<li>
<a target='_blank' href='https://ajkerdeal.com/category/Eid-Poshra-Tupi-Tasbeeh-Ittar'>টুপি, তসবি, আতর </a>
</li>
<li>
<a target='_blank' href='https://ajkerdeal.com/category/Eid-Poshra-Zakat-Products'>জাকাতের পণ্য</a>
</li>
<li>
<a target='_blank' href='https://ajkerdeal.com/category/Womens-Fashion-Cosmetics-Henna-Mehendi'>মেহেদি</a>
</li>
<li>
<a target='_blank' href='https://ajkerdeal.com/category/Womens-Fashion-Lehenga'>লেহেঙ্গা </a>
</li>
<li>
<a target='_blank' href='https://ajkerdeal.com/category/Mens-Shopping-Polo-Shirts'>পোলো শার্ট</a>
</li>
<li>
<a target='_blank' href='https://ajkerdeal.com/category/Womens-Fashion-Kurti'>কূর্তী</a>
</li>
<li>
<a target='_blank' href='https://ajkerdeal.com/category/Sunglasses-Frame'>সানগ্লাস</a>
</li>-->
                        <!--</ul>

</li>-->


                        <li class="main-mega">
                            <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping">ছেলেদের শপিং <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                            <ul class="sub-category" style="background-color: #F5F5F5;">
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-pants">প্যান্ট <i class="fa fa-angle-right" aria-hidden="true"></i> </a>
                                    <ul class="sub-sub-category">
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-pants-jeans">জিন্স</a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-pants-scratched-jeans">স্ক্র্যাচড জিন্স </a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-pants-twill-gabardine">টুইল/গ্যাবার্ডিন</a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-pants-formal">ফর্মাল</a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-pants-chinos">চিনো</a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-pants-cargo-shorts">কার্গো এন্ড শর্টস </a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-t-shirts">টি - শার্ট <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                    <ul class="sub-sub-category">
                                        <li> <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-t-shirts-thematic">থিমেটিক</a></li>
                                        <li> <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-t-shirts-text">টেক্সট</a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-t-shirts-design">ডিজাইন</a></li>
                                        <li> <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-t-shirts-combo-offer">কম্বো অফার </a></li>
                                        <li>  <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-t-shirts-solid-color">সলিড কালার </a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-shirts">শার্ট <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                    <ul class="sub-sub-category">
                                        <li>    <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-shirts-full-sleeve">ফুল-স্লিভ </a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-shirts-half-sleeve">হাফ-স্লিভ</a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-shirts-denim-shirt">ডেনিম শার্ট</a></li>
                                        <li>  <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-shirts-formal">ফর্মাল</a></li>
                                        <li>  <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-shirts-casual">ক্যাজুয়াল</a></li>
                                    </ul>

                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-polo-shirts">পোলো শার্ট <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                    <ul class="sub-sub-category">
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-polo-shirts-solid-color">সলিড কালার</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-polo-shirts-multicolor">মাল্টি-কালার</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-polo-shirts-striped">স্ট্রাইপড</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-polo-shirts-original">অরিজিনাল</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-polo-shirts-combo-offer">কম্বো অফার</a>
                                        </li>
                                    </ul>

                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-watches">
                                        ঘড়ি
                                        <i class="fa fa-angle-right" aria-hidden="true"></i>
                                    </a>
                                    <ul class="sub-sub-category">
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-watches-metal-chain">মেটাল চেইন</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-watches-leather-strap">লেদার স্ট্র্যাপ</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-watches-synthetic-strap">সিনথেটিক স্ট্র্যাপ</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-watches-original-brand">অরিজিনাল ব্র্যান্ড</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-watches-sports-watch">স্পোর্টস ওয়াচ</a>
                                        </li>
                                    </ul>

                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-shoes-sandals">
                                        জুতা ও স্যান্ডেল
                                        <i class="fa fa-angle-right" aria-hidden="true"></i>
                                    </a>
                                    <ul class="sub-sub-category">
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-shoes-sandals-formal-shoes">ফর্মাল সুজ</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/shoes-sandals-gents-gentsloafers">লোফার</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/shoes-sandals-gents-converse-sneakers">কনভার্স/ স্নিকার</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/shoes-sandals-gents-high-boot">হাই বুট</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-shoes-sandals-casual-shoes">ক্যাজুয়াল সুজ</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-shoes-sandals-sandals">স্যান্ডেল</a>
                                        </li>
                                    </ul>

                                </li>
                                <li><a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-blazer">ব্লেজার </a></li>
                            </ul>
                        </li>
                        <li class="main-mega">
                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion">মেয়েদের শপিং <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                            <ul class="sub-category" style="background-color: #F5F5F5;">
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-sharee">শাড়ি <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                    <ul class="sub-sub-category">
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-sharee-cotton">সুতি </a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-sharee-hand-painted-saree">হ্যান্ড পেইন্টেড শাড়ি</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-sharee-red-saree-for-festival">উৎসবের লাল শাড়ি</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-sharee-tangail">টাঙ্গাইল </a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-sharee-taant">তাঁত</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-sharee-kota">কোটা</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-salwar-kameez">সালোয়ার কামিজ <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                    <ul class="sub-sub-category">
                                        <li class="title-subsubcategory-li">
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-salwar-kameez-unstitched">আনস্টিচড</a>
                                        </li>
                                        <li class="title-subsubcategory-li">
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-salwar-kameez-readymade">রেডিমেড</a>
                                        </li>
                                        <li class="title-subsubcategory-li">
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-salwar-kameez-original-collection">অরিজিনাল কালেকশন </a>
                                        </li>
                                        <li class="title-subsubcategory-li">
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-salwar-kameez-replica">রেপ্লিকা</a>
                                        </li>
                                        <li class="title-subsubcategory-li">
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-salwar-kameez-deshi-boutique">দেশী বুটিক</a>
                                        </li>
                                        <li class="title-subsubcategory-li">
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-salwar-kameez-lawn">লন</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-kurti">কূর্তী <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                    <ul class="sub-sub-category">
                                        <li class="title-subsubcategory-li">
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-kurti-long">লং</a>
                                        </li>
                                        <li class="title-subsubcategory-li">
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-kurti-short">শর্ট</a>
                                        </li>
                                        <li class="title-subsubcategory-li">
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-kurti-kurti-with-leggings-palazzo">কূর্তী উইথ লেগিংস/ পালাজ্জো</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-jewellery">গহনা<i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                    <ul class="sub-sub-category">
                                        <li class="title-subsubcategory-li">
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-jewellery-necklace">নেকলেস</a>
                                        </li>
                                        <li class="title-subsubcategory-li">
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-jewellery-pendant">পেনড্যান্ট</a>
                                        </li>
                                        <li class="title-subsubcategory-li">
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-jewellery-bracelet">ব্রেসলেট</a>
                                        </li>
                                        <li class="title-subsubcategory-li">
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-jewellery-bangles">চুড়ি</a>
                                        </li>
                                        <li class="title-subsubcategory-li">
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-jewellery-earrings">ইয়ার রিং</a>
                                        </li>
                                        <li class="title-subsubcategory-li">
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-jewellery-finger-ring">আংটি</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-watch">ঘড়ি<i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                    <ul class="sub-sub-category">
                                        <li class="title-subsubcategory-li">
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-watch-metal-chain">মেটাল চেইন</a>
                                        </li>
                                        <li class="title-subsubcategory-li">
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-watch-leather-strap">লেদার স্ট্র্যাপ</a>
                                        </li>
                                        <li class="title-subsubcategory-li">
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-watch-original-brand">অরিজিনাল ব্র্যান্ড</a>
                                        </li>
                                        <li class="title-subsubcategory-li">
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-watch-original-brand">অরিজিনাল ব্র্যান্ড</a>
                                        </li>

                                    </ul>
                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-bags">ব্যাগ ও পার্স<i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                    <ul class="sub-sub-category">
                                        <li class="title-subsubcategory-li">
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-bags-vanity-bag-handbag">ভ্যানিটি ব্যাগ/ হ্যান্ডব্যাগ</a>
                                        </li>
                                        <li class="title-subsubcategory-li">
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-bags-purse-clutch">পার্স/ ক্লাচ</a>
                                        </li>
                                        <li class="title-subsubcategory-li">
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-bags-party-bag">পার্টি ব্যাগ</a>
                                        </li>
                                        <li class="title-subsubcategory-li">
                                            <a target="_blank" href="https://ajkerdeal.com/category/leather-items-ladies-bag">লেদার ব্যাগ</a>
                                        </li>
                                        <li class="title-subsubcategory-li">
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-bags-wallet">ওয়ালেট</a>
                                        </li>

                                    </ul>
                                </li>
                            </ul>
                            <!--<ul class="mega-menu">
<li class="single-menu">
    <a href="#" class="title-link">Shop Kid's</a>
    <div class="image">
        <img src="https://via.placeholder.com/225x155" alt="#">
    </div>
    <div class="inner-link">
        <a href="#">Kids Toys</a>
        <a href="#">Kids Travel Car</a>
        <a href="#">Kids Color Shape</a>
        <a href="#">Kids Tent</a>
    </div>
</li>
<li class="single-menu">
    <a href="#" class="title-link">Shop Men's</a>
    <div class="image">
        <img src="https://via.placeholder.com/225x155" alt="#">
    </div>
    <div class="inner-link">
        <a href="#">Watch</a>
        <a href="#">T-shirt</a>
        <a href="#">Hoodies</a>
        <a href="#">Formal Pant</a>
    </div>
</li>
<li class="single-menu">
    <a href="#" class="title-link">Shop Women's</a>
    <div class="image">
        <img src="https://via.placeholder.com/225x155" alt="#">
    </div>
    <div class="inner-link">
        <a href="#">Ladies Shirt</a>
        <a href="#">Ladies Frog</a>
        <a href="#">Ladies Sun Glass</a>
        <a href="#">Ladies Watch</a>
    </div>
</li>
</ul>-->
                        </li>
                        <li>
                            <a target="_blank" href="https://ajkerdeal.com/category/household">গৃহস্থালী সামগ্রী <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                            <ul class="sub-category" style="background-color: #F5F5F5;">
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/household-home-appliances">হোম অ্যাপ্লায়েন্স <i class="fa fa-angle-right" aria-hidden="true"></i> </a>
                                    <ul class="sub-sub-category">
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/television">টিভি</a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-refrigerator-freezer">রেফ্রিজারেটর/ ফ্রিজার </a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/air-conditioner">এয়ার কন্ডিশনার</a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/washing-machine-and-cloth-dryer">ওয়াশিং মেশিন/ ড্রায়ার</a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/household-fan">ফ্যান</a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/household-home-appliances-torch">টর্চ </a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/home-decor-furniture">ফার্নিচার <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                    <ul class="sub-sub-category">
                                        <li> <a target="_blank" href="https://ajkerdeal.com/category/home-decor-furniture-almirah">আলমারী</a></li>
                                        <li> <a target="_blank" href="https://ajkerdeal.com/category/home-decor-furniture-cot-mattress">খাট/ ম্যাট্রেস</a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/home-decor-furniture-inflatable-bed">ইনফ্ল্যাটেবল বেড</a></li>
                                        <li> <a target="_blank" href="https://ajkerdeal.com/category/home-decor-furniture-showcase">শো-কেস </a></li>
                                        <li>  <a target="_blank" href="https://ajkerdeal.com/category/home-decor-furniture-wardrobe">ওয়্যারড্রোব </a></li>
                                        <li>  <a target="_blank" href="https://ajkerdeal.com/category/home-decor-furniture-dressing-table">ড্রেসিং টেবিল </a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/household-tools-machinery">টুলস অ্যান্ড মেশিনারি <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                    <ul class="sub-sub-category">
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/household-tools-machineries-water-pump">ওয়াটার পাম্প </a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/cleanning-machine">ক্লিনিং মেশিন</a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/household-tools-machineries-hosepipe">হোস পাইপ</a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/household-tools-machineries-insect-repellent">ইনসেক্ট রিপেলেন্ট</a></li>
                                        <li> <a target="_blank" href="https://ajkerdeal.com/category/household-tools-machineries-multi-function-tool">মাল্টি ফাংশন টুলস</a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/household-tools-machinery-electric-air-pump">ইলেকট্রিক এয়ার পাম্প</a></li>
                                    </ul>

                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/household-toilet-accessories">টয়লেট এক্সেসরিজ <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                    <ul class="sub-sub-category">
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/household-toilet-accessories-soap-case-dispenser">সোপ কেস/ ডিসপেন্সার</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/household-toilet-accessories-toothpaste-dispenser">টুথপেস্ট ডিসপেন্সার</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/household-toilet-accessories-toothbrush-holder">টুথব্রাশ হোল্ডার</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/household-toilet-accessories-hand-wash-cleanser">হ্যান্ডওয়াশ/ক্লিনজার</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/household-toilet-accessories-toothpaste">টুথপেস্ট</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/household-toilet-accessories-electric-hot-shower">ইলেকট্রিক হট শাওয়ার</a>
                                        </li>
                                    </ul>

                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/household-essentials">
                                        নিত্য প্রয়োজনীয়
                                        <i class="fa fa-angle-right" aria-hidden="true"></i>
                                    </a>
                                    <ul class="sub-sub-category">
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/household-essentials-mosquito-net">মশারী</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/household-essentials-air-freshener">এয়ার ফ্রেশনার</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/household-essentials-detergent-cleaner">ডিটারজেন্ট ও ক্লিনার</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/household-essentials-boblin-remover">ববলিন রিমুভার</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/household-essentials-others">অন্যান্য</a>
                                        </li>
                                    </ul>

                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/household-fan">
                                        ফ্যান
                                        <i class="fa fa-angle-right" aria-hidden="true"></i>
                                    </a>
                                    <ul class="sub-sub-category">
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/household-fan-ceiling-fan">সিলিং ফ্যান</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/household-fan-table-fan">টেবিল ফ্যান</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/household-fan-stand-fan">স্ট্যান্ড ফ্যান</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/household-fan-mini-fan">মিনি ফ্যান</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/household-fan-rechargeable-fans">রিচার্জ্যাবল ফ্যান</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/household-fan-multi-function-fan">মাল্টি-ফাংশন ফ্যান</a>
                                        </li>
                                    </ul>

                                </li>

                            </ul>

                        </li>
                        <li>
                            <a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining">কিচেন এন্ড  ডাইনিং <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                            <ul class="sub-category" style="height:460px; background:#F5F5F5;">
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-refrigerator-freezer">রেফ্রিজারেটর/ ফ্রিজার  <i class="fa fa-angle-right" aria-hidden="true"></i> </a>
                                    <ul class="sub-sub-category">
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-refrigerator-freezer-refrigerator">রেফ্রিজারেটর</a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-refrigerator-freezer-freezer">ফ্রিজার </a></li>

                                    </ul>
                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-crockeries">ক্রোকারিজ <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                    <ul class="sub-sub-category">
                                        <li> <a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-crockeries-plates-dishes">প্লেট ও ডিশ</a></li>
                                        <li> <a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-crockeries-glass-jug">গ্লাস ও জগ</a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-crockeries-bowls-cups">বোল ও বাটি</a></li>
                                        <li> <a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-crockeries-serving-set-tray">সার্ভিং সেট/ ট্রে </a></li>
                                        <li>  <a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-crockeries-tea-set">টি-সেট </a></li>
                                        <li>  <a target="_blank" href="https://ajkerdeal.com/category/fancy-gift-items-mug">কফি মগ </a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-knife-scissors-spoon">ছুরি, কাঁচি ও চামচ <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                    <ul class="sub-sub-category">
                                        <li>    <a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-knife-scissors-spoon-kitchen-knives">কিচেন নাইফ  </a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-knife-scissors-spoon-kitchen-scissors">কিচেন সিজরস</a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-knife-scissors-spoon-spoon-fork">স্পুন এন্ড ফর্ক</a></li>

                                    </ul>

                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/kitchen-dining-roti-noodles-biscuit-maker">রুটি/ নুডুলস/ বিস্কিট মেকার <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                    <ul class="sub-sub-category">
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-roti-noodles-biscuit-maker-noodles-semai-maker">নুডলস ও সেমাই মেকার</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/roti-maker">রুটি ও পুরি মেকার</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-roti-noodles-biscuit-maker-biscuit-cake-maker">বিস্কিট/ কেক মেকার</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-roti-noodles-biscuit-maker-dough-maker">ডো মেকার</a>
                                        </li>

                                    </ul>

                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-oven">
                                        ওভেন
                                    </a>


                                </li>
                                <li>

                                    <a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-pressure-cooker">প্রেশার কুকার</a>
                                </li>

                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-rice-cooker">রাইস কুকার</a>
                                </li>

                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-cookware-set">কুকওয়্যার সেট</a>
                                </li>

                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-barbecue-grill">বারবিকিউ গ্রিল</a>
                                </li>

                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-induction-cooker-fryer">ইন্ডাকশন কুকার/ ফ্রায়ার</a>
                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-multicooker">মাল্টিকুকার</a>
                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-mixer-grinder">মিক্সার ও গ্রাইন্ডার</a>
                                </li>

                                <li>

                                    <a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-blender-juice-maker">ব্লেন্ডার ও জুস মেকার</a>
                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-frying-pan">ফ্রাইং প্যান</a>
                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/kitchen-dining-knife-sharpener">নাইফ শার্পনার</a>
                                </li>

                            </ul>

                        </li>
                        <!--<li>
<a target='_blank' href='https://ajkerdeal.com/category/mobile'>মোবাইল <i class="fa fa-angle-right" aria-hidden="true"></i></a>
<ul class="sub-category">
<li>
    <a target='_blank' href='https://ajkerdeal.com/category/smartphones'>স্মার্ট ফোন <i class="fa fa-angle-right" aria-hidden="true"></i> </a>
    <ul class="sub-sub-category">
        <li><a target='_blank' href='https://ajkerdeal.com/category/smartphone-original'>অরিজিনাল</a></li>
        <li><a target='_blank' href='https://ajkerdeal.com/category/android'>অ্যান্ড্রয়েড </a></li>
        <li><a target='_blank' href='https://ajkerdeal.com/category/apple-iphone'>আইফোন</a></li>
        <li><a target='_blank' href='https://ajkerdeal.com/category/windows-phone'>উইন্ডোজ</a></li>
        <li><a target='_blank' href='https://ajkerdeal.com/category/blackberry'>ব্ল্যাকবেরি</a></li>
        <li><a target='_blank' href='https://ajkerdeal.com/category/smartphones-under-tk-10000'>১০ হাজার টাকার মধ্যে </a></li>
    </ul>
</li>
<li>
    <a target='_blank' href='https://ajkerdeal.com/category/xiaomi-mobile'>শাওমি <i class="fa fa-angle-right" aria-hidden="true"></i></a>
    <ul class="sub-sub-category">
        <li> <a target='_blank' href='https://ajkerdeal.com/category/xiaomi-mi-max-2'>শাওমি এম আই ম্যাক্স ২</a></li>
        <li> <a target='_blank' href='https://ajkerdeal.com/category/xiaomi-redmi-4x'>শাওমি রেডমি ৪ এক্স</a></li>
        <li><a target='_blank' href='https://ajkerdeal.com/category/xiaomi-redmi-note-4'>শাওমি রেডমি নোট ৪</a></li>
        <li> <a target='_blank' href='https://ajkerdeal.com/category/xiaomi-mi-mix'>শাওমি এম আই মিক্স </a></li>
        <li>  <a target='_blank' href='https://ajkerdeal.com/category/xiaomi-redmi-5-plus'>শাওমি রেডমি ৫ প্লাস </a></li>
        <li>  <a target='_blank' href='https://ajkerdeal.com/category/xiaomi-redmi-note-5-pro'>শাওমি রেডমি নোট ৫ প্রো </a></li>
    </ul>
</li>
<li>
    <a target='_blank' href='https://ajkerdeal.com/category/asus-mobile'>Asus <i class="fa fa-angle-right" aria-hidden="true"></i></a>
    <ul class="sub-sub-category">
        <li>    <a target='_blank' href='https://ajkerdeal.com/category/asus-zenfone-5-mobile'>আসুস জেনফোন 5 </a></li>

    </ul>

</li>
<li>
    <a target='_blank' href='https://ajkerdeal.com/category/nokia-mobile'>Nokia <i class="fa fa-angle-right" aria-hidden="true"></i></a>
    <ul class="sub-sub-category">
        <li>
            <a target='_blank' href='https://ajkerdeal.com/category/nokia-6'>নোকিয়া ৬</a>
        </li>
        <li>
            <a target='_blank' href='https://ajkerdeal.com/category/nokia-5'>নোকিয়া ৫</a>
        </li>
        <li>
            <a target='_blank' href='https://ajkerdeal.com/category/nokia-mobile-nokia-3310'>নোকিয়া ৩৩১০</a>
        </li>

    </ul>

</li>
<li>
    <a target='_blank' href='https://ajkerdeal.com/category/feature-mobile-phone'>
        ফিচার ফোন
        <i class="fa fa-angle-right" aria-hidden="true"></i>
    </a>
    <ul class="sub-sub-category">
        <li>
            <a target='_blank' href='https://ajkerdeal.com/category/popular-feature-phones'>পপুলার ব্র্যান্ড</a>
        </li>
        <li>
            <a target='_blank' href='https://ajkerdeal.com/category/mens-shopping-watches-leather-strap'>লেদার স্ট্র্যাপ</a>
        </li>
        <li>
            <a target='_blank' href='https://ajkerdeal.com/category/mobile-at-tk-999'>মোবাইল @ ৳ ৯৯৯</a>
        </li>
        <li>
            <a target='_blank' href='https://ajkerdeal.com/category/4-sim-mobile'>৪-সিম মোবাইল</a>
        </li>
        <li>
            <a target='_blank' href='https://ajkerdeal.com/category/mini-card-phone'>মিনি কার্ড ফোন</a>
        </li>
        <li>
            <a target='_blank' href='https://ajkerdeal.com/category/mobile-with-power-bank'>মোবাইল কাম পাওয়ার ব্যাঙ্ক</a>
        </li>
    </ul>

</li>
<li>
    <a target='_blank' href='https://ajkerdeal.com/category/mobile-iphone'>
        iPhone
        <i class="fa fa-angle-right" aria-hidden="true"></i>
    </a>
    <ul class="sub-sub-category">
        <li>
            <a target='_blank' href='https://ajkerdeal.com/category/mobile-iphone-iphone-7-plus'>আইফোন ৭ প্লাস</a>
        </li>
        <li>
            <a target='_blank' href='https://ajkerdeal.com/category/mobile-iphone-iphone-7'>আইফোন ৭</a>
        </li>
        <li>
            <a target='_blank' href='https://ajkerdeal.com/category/mobile-iphone-iphone-8'>আইফোন ৮</a>
        </li>
        <li>
            <a target='_blank' href='https://ajkerdeal.com/category/mobile-iphone-iphone-x'>আইফোন ১০</a>
        </li>

    </ul>

</li>
<li>
    <a target='_blank' href='https://ajkerdeal.com/category/vivo-mobile'>
        Vivo

    </a>

</li>

</ul>

</li>-->
                        <li>
                            <a target="_blank" href="https://ajkerdeal.com/category/computer-accessories">কম্পিউটার এক্সেসরিজ <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                            <ul class="sub-category" style="background-color: #F5F5F5;">
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-mouse">মাউস <i class="fa fa-angle-right" aria-hidden="true"></i> </a>
                                    <ul class="sub-sub-category">
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-mouse-wired">ওয়্যারড</a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-mouse-wireless">ওয়্যারলেস </a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-mouse-gaming-mouse">গেমিং মাউস</a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-mouse-touch-pen-mouse">টাচ পেন মাউস</a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-mouse-remote-mouse-pointer">রিমোট মাউস</a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-mouse-toy-shaped-mouse">টয়-শেপড মাউস </a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-key-board">কীবোর্ড <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                    <ul class="sub-sub-category">
                                        <li> <a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-key-board-wired">ওয়্যারড</a></li>
                                        <li> <a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-key-board-wireless">ওয়্যারলেস</a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-key-board-flexible-key-board">ফ্লেক্সিবল কি-বোর্ড</a></li>
                                        <li> <a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-key-board-virtual-key-board">ভার্চুয়াল কি-বোর্ড </a></li>
                                        <li>  <a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-key-board-ultra-mini-key-board">আল্ট্রা মিনি কি-বোর্ড </a></li>
                                        <li>  <a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-key-board-gaming-key-board">গেমিং কি-বোর্ড </a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-monitor">মনিটর <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                    <ul class="sub-sub-category">
                                        <li>    <a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-monitor-monitor">মনিটর </a></li>
                                        <li>    <a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-monitor-tv-cum-monitor">টিভি কাম মনিটর </a></li>

                                    </ul>

                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-speaker-microphone">স্পিকার/ মাইক্রোফোন <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                    <ul class="sub-sub-category">
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-speaker-microphone-wired-speaker">ওয়্যারড স্পীকার</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-speaker-microphone-bluetooth-wireless-speaker">ব্লু-টুথ/ ওয়্যারলেস স্পীকার</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-speaker-microphone-microphone">মাইক্রোফোন</a>
                                        </li>

                                    </ul>

                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-headphone">
                                        হেডফোন
                                        <i class="fa fa-angle-right" aria-hidden="true"></i>
                                    </a>
                                    <ul class="sub-sub-category">
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-headphone-wired">ওয়্যারড</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-headphone-wireless">ওয়্যারলেস</a>
                                        </li>

                                    </ul>

                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-network-accessories">
                                        নেটওয়ার্ক এক্সেসরিজ
                                        <i class="fa fa-angle-right" aria-hidden="true"></i>
                                    </a>
                                    <ul class="sub-sub-category">
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-network-accessories-modem">মডেম</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-network-accessories-router">রাউটার</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-network-accessories-switch">সুইচ</a>
                                        </li>


                                    </ul>

                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/computer-accessories-web-cam">
                                        ওয়েব ক্যাম

                                    </a>

                                </li>

                            </ul>

                        </li>
                        <li>
                            <a target="_blank" href="https://ajkerdeal.com/category/gadgets">গ্যাজেটস <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                            <ul class="sub-category" style="height:350px; background:#F5F5F5;">
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/gadgets-tab">ট্যাব <i class="fa fa-angle-right" aria-hidden="true"></i> </a>
                                    <ul class="sub-sub-category">
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/gadgets-tab-original">অরিজিনাল</a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/gadgets-tab-copy">কপি </a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/gadgets-tab-kids-tab">কিডস ট্যাব</a></li>

                                    </ul>
                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/gadgets-security-gadgets">সিকিউরিটি গ্যাজেটস <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                    <ul class="sub-sub-category">
                                        <li> <a target="_blank" href="https://ajkerdeal.com/category/gadgets-security-gadgets-cc-camera">CC ক্যামেরা</a></li>
                                        <li> <a target="_blank" href="https://ajkerdeal.com/category/gadgets-security-gadgets-ip-camera">IP ক্যামেরা</a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/gadgets-security-gadgets-nvr-dvr">NVR/ DVR</a></li>
                                        <li> <a target="_blank" href="https://ajkerdeal.com/category/gadgets-security-gadgets-metal-detector">মেটাল ডিটেক্টর </a></li>
                                        <li>  <a target="_blank" href="https://ajkerdeal.com/category/gadgets-security-gadgets-metal-detector-gate">মেটাল ডিটেক্টর গেট </a></li>

                                    </ul>
                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/gadgets-mini-usb-gadget">মিনি ইউএসবি গ্যাজেট <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                    <ul class="sub-sub-category">
                                        <li>    <a target="_blank" href="https://ajkerdeal.com/category/gadgets-mini-usb-gadget-mini-usb-fan">মিনি ইউএসবি ফ্যান </a></li>
                                        <li>    <a target="_blank" href="https://ajkerdeal.com/category/gadgets-mini-usb-gadget-mini-usb-fridge">মিনি ইউএসবি ফ্রিজ </a></li>
                                        <li>    <a target="_blank" href="https://ajkerdeal.com/category/gadgets-mini-usb-gadget-mini-usb-air-cooler">মিনি ইউএসবি এয়ার কুলার </a></li>

                                    </ul>

                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/television">
                                        টেলিভিশন
                                        <i class="fa fa-angle-right" aria-hidden="true"></i>
                                    </a>
                                    <ul class="sub-sub-category">
                                        <!--<ul class="sub-sub-category" style="height:350px; background:#fff;">-->
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/television-sony">Sony</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/television-walton">Walton</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/television-lg">LG</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/television-up-to-14-inch">১৪" পর্যন্ত</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/television-15inch-to-32inch">১৫"-৩২"</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/television-33inch-to-55inch">৩৩"-৫৫"</a>
                                        </li>
                                    </ul>

                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/gadgets-laptop">ল্যাপটপ </a>


                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/gadgets-camera">ক্যামেরা</a>


                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/watches-clock-smart-watch">স্মার্ট ওয়াচ </a>


                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/gadgets-game-console">গেম কনসোল </a>


                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/gadgets-mp3-player">এমপিথ্রি প্লেয়ার </a>


                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/gadgets-vr-box">VR বক্স </a>


                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/gadgets-voice-recorder">ভয়েস রেকর্ডার </a>


                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/android-tv-box">অ্যান্ড্রয়েড টিভি বক্স </a>


                                </li>





                            </ul>

                        </li>
                        <li>
                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-jewellery">গহনা <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                            <ul class="sub-category" style="background-color: #F5F5F5;">
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/jewelry-necklace-pendant">নেকলেস ও পেনড্যান্ট <i class="fa fa-angle-right" aria-hidden="true"></i> </a>
                                    <ul class="sub-sub-category">
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-jewellery-necklace">নেকলেস</a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-jewellery-pendant">পেনড্যান্ট </a></li>

                                    </ul>
                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/jewelry-bangles-bracelet">চুড়ি ও ব্রেসলেট <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                    <ul class="sub-sub-category">
                                        <li> <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-jewellery-bangles">চুড়ি</a></li>
                                        <li> <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-jewellery-bracelet">ব্রেসলেট</a></li>

                                    </ul>
                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/jewelry-finger-ring-ear-ring">আংটি ও ইয়ার রিং <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                    <ul class="sub-sub-category">
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-jewellery-finger-ring">আংটি </a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-jewellery-earrings">ইয়ার রিং</a></li>

                                    </ul>

                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/jewelry-clip-and-band"> ক্লিপ ও ব্যান্ড <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                    <ul class="sub-sub-category">
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-jewellery-brooch-cloth-clip">ব্রোচ ও ক্লথ ক্লিপ</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-jewellery-hair-band-clip">হেয়ার ব্যান্ড ও ক্লিপ</a>
                                        </li>

                                    </ul>

                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/jewelry-tikli-and-waist-chain">
                                        টিকলি ও বিছা
                                        <i class="fa fa-angle-right" aria-hidden="true"></i>
                                    </a>
                                    <ul class="sub-sub-category">
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-jewellery-tiklee-tiara">টিকলি ও টায়রা</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-jewellery-waist-chain">বিছা</a>
                                        </li>

                                    </ul>

                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-jewellery-payel-anklet">
                                        পায়েল ও নুপুর
                                        <i class="fa fa-angle-right" aria-hidden="true"></i>
                                    </a>
                                    <ul class="sub-sub-category">
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/jewelry-anklet-and-payel-payel">পায়েল</a>
                                        </li>
                                        <li>
                                            <a target="_blank" href="https://ajkerdeal.com/category/jewelry-anklet-and-payel-anklet">নুপুর</a>
                                        </li>

                                    </ul>

                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-jewellery-nose-ring">
                                        নাকফুল

                                    </a>

                                </li>


                            </ul>

                        </li>
                        <li>
                            <a target="_blank" href="https://ajkerdeal.com/category/watches-clock">ঘড়ি<i class="fa fa-angle-right" aria-hidden="true"></i></a>
                            <ul class="sub-category" style="background-color: #F5F5F5;">


                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-watches">জেন্টস ওয়াচ <i class="fa fa-angle-right" aria-hidden="true"></i> </a>
                                    <ul class="sub-sub-category">
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-watches-metal-chain">মেটাল চেইন</a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-watches-leather-strap">লেদার স্ট্র্যাপ </a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-watches-original-brand">অরিজিনাল ব্র্যান্ </a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/mens-shopping-watches-sports-watch">স্পোর্টস ওয়াচ </a></li>




                                    </ul>
                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-watch">লেডিজ ওয়াচ <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                    <ul class="sub-sub-category">
                                        <li> <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-watch-metal-chain">মেটাল চেইন</a></li>
                                        <li> <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-watch-leather-strap">লেদার স্ট্র্যাপ</a></li>
                                        <li> <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-watch-synthetic-strap">সিনথেটিক স্ট্র্যাপ</a></li>
                                        <li> <a target="_blank" href="https://ajkerdeal.com/category/womens-fashion-watch-original-brand">অরিজিনাল ব্র্যান্</a></li>


                                    </ul>
                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/category/watches-clock-smart-watch">স্মার্ট ওয়াচ <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                    <ul class="sub-sub-category">
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/watches-clock-smart-watch-simless">সিমলেস </a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/watches-clock-smart-watch-sim-supported">সিম সাপোর্টেড </a></li>
                                        <li><a target="_blank" href="https://ajkerdeal.com/category/watches-clock-smart-watch-smart-watch-accessories">স্মার্ট ওয়াচ এক্সেসরিজ </a></li>


                                    </ul>

                                </li>

                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/watches-clock-couple-watch">
                                        কাপল ওয়াচ

                                    </a>

                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/watches-clock-kids-watch">
                                        কিডস ওয়াচ

                                    </a>

                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/watches-clock-original-brand">
                                        অরিজিনাল ব্র্যান্

                                    </a>

                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/watches-clock-table-clock">
                                        টেবিল ক্লক

                                    </a>

                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/watches-clock-wall-clock">
                                        ওয়াল ক্লক

                                    </a>

                                </li>
                                <li>
                                    <a target="_blank" href="https://ajkerdeal.com/watches-clock-projection-clock">
                                        প্রজেকশন ক্লক

                                    </a>


                                </li>


                            </ul>

                        </li>
                        <li>
                            <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor">গৃহসজ্জা <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                            <ul class="sub-category" style=" background:#F5F5F5;">
                            <li>
                            <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor-Bed-Sheet-Cover">বেডশীট ও কভার <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                            <ul class="sub-sub-category">
                            <li>    <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor-Bed-Sheet-Cover-Double">ডাবল  </a></li>
                            <li>    <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor-Bed-Sheet-Cover-Semi-double">সেমি-ডাবল  </a></li>
                            <li>    <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor-Bed-Sheet-Cover-Single">সিঙ্গেল </a></li>
                            <li>    <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor-Bed-Sheet-Cover-4-pieces-Set">৪ পিসের সেট   </a></li>
                            <li>    <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor-Bed-Sheet-Cover-6-Pieces-Set">৬ পিসের সেট   </a></li>
                            <li>    <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor-Bed-Sheet-Cover-8-Pieces-Set">৮ পিসের সেট  </a></li>
                            <li>    <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor-Bed-Sheet-Cover-Nakshi-Kantha-Style-Bed-Sheet">নকশী কাঁথা স্টাইল বেড শীট  </a></li>

                            </ul>

                            </li>
                            <li>
                            <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor-Furniture">ফার্নিচার <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                            <ul class="sub-sub-category">
                            <li>    <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor-Furniture-Table">টেবিল</a></li>
                            <li>    <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor-Furniture-Shelf-Rack">শেলফ/ র&zwnj;্যাক </a></li>
                            <li>    <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor-Furniture-Trolley">ট্রলি</a></li>
                            <li>    <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor-Furniture-Showcase">শো-কেস </a></li>
                            <li>    <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor-Furniture-Almirah">আলমারী </a></li>
                            <li>    <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor-Furniture-Cot-Mattress">খাট/ ম্যাট্রেস </a></li>
                            <li>    <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor-Furniture-Wardrobe">ওয়্যারড্রোব </a></li>
                            <li>    <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor-Furniture-Dressing-Table">ড্রেসিং টেবিল </a></li>
                            <li>    <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor-Furniture-Sofa">সোফা </a></li>
                            <li>    <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor-Furniture-Chair">চেয়ার</a></li>
                           
                            </ul>

                            </li>
                            <li>
                            <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor-Pillow-Cushion">পিলো ও কুশন</a>

                            </li>
                            <li>
                            <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor-Curtain">পর্দা </a>
                            </li>
                            <li>
                            <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor-Duvet-Blanket">ডুভেট/ব্ল্যাঙ্কেট</a>
                            </li>
                            <li>
                            <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor-Decoration-Lamp-Shade">ডেকোরেশন ল্যাম্প ও শেড </a>
                            </li>
                            <li>
                            <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor-Flower-Vase">
                            ফুলদানি
                            </a>

                            </li>
                            <li>
                            <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor-Photo-Frame">
                            ফটো ফ্রেম

                            </a>

                            </li>
                            <li>
                            <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor-Showpiece">
                            শো-পিস

                            </a>

                            </li>
                            <li>
                            <a target="_blank" href="https://ajkerdeal.com/category/Home-Decor-Nokshi-Kantha">নকশী কাঁথা</a>
                            </li>
                            </ul>

                        </li>
                        <li><a href="https://ajkerdeal.com/allcategories.aspx">সকল শপিং ক্যাটাগরি &gt;&gt; </a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class=" col-lg-6 colm_none">
            <div class="search_container search_seven_c" id="search_product">
                <form action="#">
                    {{-- <div class="hover_category">
                                        <select class="select_option" name="select" id="categori2">
                                            <option selected value="1">All Categories</option>
                                            <option value="2">Accessories</option>
                                            <option value="3">Accessories & More</option>
                                            <option value="4">Butters & Eggs</option>
                                            <option value="5">Camera & Video </option>
                                            <option value="6">Mornitors</option>
                                            <option value="7">Tablets</option>
                                            <option value="8">Laptops</option>
                                            <option value="9">Handbags</option>
                                            <option value="10">Headphone & Speaker</option>
                                            <option value="11">Herbs & botanicals</option>
                                            <option value="12">Vegetables</option>
                                            <option value="13">Shop</option>
                                            <option value="14">Laptops & Desktops</option>
                                            <option value="15">Watchs</option>
                                            <option value="16">Electronic</option>
                                        </select>
                                    </div> --}}
                    <div class="search_box">
                        <input type="text" v-model="search_key" style="padding-left:10px;"
                            placeholder="Search Products…" />
                        <button type="submit">Search</button>
                    </div>
                </form>
            </div>

        </div>
        <div class=" col-lg-3 col-md-6">
            <div class="header_bigsale">
                <a href="#">BIG SALE BLACK FRIDAY</a>
            </div>
        </div>
    </div>
</div>