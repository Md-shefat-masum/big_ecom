@extends('frontend.frontend')
@section('content')
@include('frontend.include.banner')
@include('frontend.include.add-banner')
@include('frontend.include.latest-product')
@include('frontend.include.categoris')
@endsection
