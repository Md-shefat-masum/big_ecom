<div class="logo hm3-logo">
    <a href="/">
        <img src="<?php echo e(asset('contents/website')); ?>/img/logo/1.png" alt="" />
    </a>
</div>
<?php /**PATH D:\xampp\htdocs\Laravel_Core_Files\default_dashboard\laravel8 dashtreme\resources\views/website/ecommerce/layouts/logo.blade.php ENDPATH**/ ?>